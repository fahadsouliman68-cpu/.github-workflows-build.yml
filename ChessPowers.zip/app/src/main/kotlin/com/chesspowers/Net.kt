package com.chesspowers

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

class Net(var onMsg: (String) -> Unit) {
    private var sock: Socket? = null
    private var server: ServerSocket? = null
    private var out: PrintWriter? = null
    private val ui = Handler(Looper.getMainLooper())
    private val sender = Executors.newSingleThreadExecutor()

    fun host() {
        Thread {
            try { server = ServerSocket(7777); run(server!!.accept()) } catch (e: Exception) { post("X") }
        }.start()
    }

    fun join(ip: String) {
        Thread {
            try { val s = Socket(); s.connect(InetSocketAddress(ip.trim(), 7777), 6000); run(s) } catch (e: Exception) { post("X") }
        }.start()
    }

    private fun run(s: Socket) {
        sock = s
        out = PrintWriter(s.getOutputStream(), true)
        post("C")
        try {
            val r = BufferedReader(InputStreamReader(s.getInputStream()))
            while (true) { val l = r.readLine() ?: break; post(l) }
        } catch (e: Exception) { }
        post("D")
    }

    private fun post(m: String) { ui.post { onMsg(m) } }
    fun send(m: String) { sender.execute { try { out?.println(m) } catch (e: Exception) { } } }
    fun close() { try { server?.close(); sock?.close() } catch (e: Exception) { } }

    companion object {
        fun localIp(): String {
            try {
                val all = NetworkInterface.getNetworkInterfaces().toList()
                    .flatMap { it.inetAddresses.toList() }
                    .filter { !it.isLoopbackAddress && it is Inet4Address }
                    .mapNotNull { it.hostAddress }
                return all.firstOrNull { it.startsWith("192.168") } ?: all.firstOrNull() ?: "?"
            } catch (e: Exception) { }
            return "?"
        }
    }
}

object Sfx {
    var on = true
    fun tone(f0: Int, f1: Int, ms: Int, vol: Int = 12000) {
        if (!on) return
        Thread {
            try {
                val n = 44100 * ms / 1000
                val d = ShortArray(n)
                var ph = 0.0
                for (i in 0 until n) {
                    val t = i / n.toDouble()
                    ph += 2 * Math.PI * (f0 + (f1 - f0) * t) / 44100
                    d[i] = (Math.sin(ph) * (1 - t) * vol).toInt().toShort()
                }
                val at = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(44100).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(n * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
                at.write(d, 0, n); at.play()
                Thread.sleep(ms + 150L); at.release()
            } catch (e: Exception) { }
        }.start()
    }
    fun move() = tone(300, 200, 120)
    fun cap() = tone(220, 60, 260)
    fun power() = tone(300, 1300, 380)
    fun win() { tone(400, 800, 700); tone(600, 1200, 700) }
}
