package com.chesspowers

import kotlin.math.abs
import kotlin.math.max

typealias Sq = Pair<Int, Int>

data class Pc(val t: Char, val w: Boolean, val cd: Int = 2, val fr: Int = 0)
data class Act(val power: Boolean, val fx: Int, val fy: Int, val tx: Int, val ty: Int)

val NAMES = mapOf('p' to "جندي", 'n' to "حصان", 'b' to "فيل", 'r' to "قلعة", 'q' to "وزير", 'k' to "ملك")
val POWER_NAME = mapOf('p' to "القنّاص", 'n' to "الانتقال", 'b' to "التحويل", 'r' to "المدفع", 'q' to "التبديل", 'k' to "التجميد")
val POWER_DESC = mapOf(
    'p' to "يطلق النار على عدو يبعد 2 إلى 3 مربعات أمامه دون أن يتحرك.",
    'n' to "ينتقل فوراً إلى أي مربع فارغ ضمن 3 مربعات حوله.",
    'b' to "يحوّل قطعة عدو (غير الملك والوزير) إلى جانبك ضمن 3 مربعات قطرية.",
    'r' to "مدفع يدمّر أول قطعة عدو في خط مستقيم ضمن 3 مربعات، حتى الملك.",
    'q' to "تبدّل مكانها مع أي قطعة من قطعك.",
    'k' to "يجمّد قطعة عدو ضمن مربعين لمدة دورين فلا تستطيع التحرك."
)

val D4 = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))
val DD = arrayOf(intArrayOf(1, 1), intArrayOf(1, -1), intArrayOf(-1, 1), intArrayOf(-1, -1))
val NN = arrayOf(intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(-1, 2), intArrayOf(-2, 1),
    intArrayOf(1, -2), intArrayOf(2, -1), intArrayOf(-1, -2), intArrayOf(-2, -1))

fun value(t: Char) = when (t) { 'p' -> 1.0; 'n' -> 3.0; 'b' -> 3.0; 'r' -> 5.0; 'q' -> 9.0; else -> 100.0 }

class State(val b: Array<Array<Pc?>>, var white: Boolean = true, var winner: Int = 0) {
    companion object {
        fun start(): State {
            val s = State(Array(8) { arrayOfNulls<Pc>(8) })
            val bk = "rnbqkbnr"
            for (x in 0..7) {
                s.b[x][0] = Pc(bk[x], true); s.b[x][1] = Pc('p', true)
                s.b[x][6] = Pc('p', false); s.b[x][7] = Pc(bk[x], false)
            }
            return s
        }
    }

    fun copy() = State(Array(8) { x -> Array<Pc?>(8) { y -> b[x][y] } }, white, winner)
    private fun inb(x: Int, y: Int) = x in 0..7 && y in 0..7

    private fun slide(p: Pc, x0: Int, y0: Int, dx: Int, dy: Int, mx: Int, l: MutableList<Sq>) {
        for (i in 1..mx) {
            val x = x0 + dx * i; val y = y0 + dy * i
            if (!inb(x, y)) break
            val o = b[x][y]
            if (o == null) l.add(x to y) else { if (o.w != p.w) l.add(x to y); break }
        }
    }

    fun moves(x0: Int, y0: Int): List<Sq> {
        val p = b[x0][y0] ?: return emptyList()
        val l = mutableListOf<Sq>()
        if (p.fr > 0) return l
        val d = if (p.w) 1 else -1
        when (p.t) {
            'p' -> {
                if (inb(x0, y0 + d) && b[x0][y0 + d] == null) {
                    l.add(x0 to y0 + d)
                    if (y0 == (if (p.w) 1 else 6) && b[x0][y0 + 2 * d] == null) l.add(x0 to y0 + 2 * d)
                }
                for (s in intArrayOf(-1, 1)) {
                    val x = x0 + s; val y = y0 + d
                    if (inb(x, y)) { val o = b[x][y]; if (o != null && o.w != p.w) l.add(x to y) }
                }
            }
            'n' -> for (m in NN) {
                val x = x0 + m[0]; val y = y0 + m[1]
                if (inb(x, y)) { val o = b[x][y]; if (o == null || o.w != p.w) l.add(x to y) }
            }
            else -> {
                val mx = if (p.t == 'k') 1 else 8
                if (p.t != 'b') for (d4 in D4) slide(p, x0, y0, d4[0], d4[1], mx, l)
                if (p.t != 'r') for (dd in DD) slide(p, x0, y0, dd[0], dd[1], mx, l)
            }
        }
        return l
    }

    fun targets(x0: Int, y0: Int): List<Sq> {
        val p = b[x0][y0] ?: return emptyList()
        val l = mutableListOf<Sq>()
        if (p.cd > 0 || p.fr > 0) return l
        when (p.t) {
            'p' -> for (i in 2..3) {
                val y = y0 + (if (p.w) i else -i)
                if (inb(x0, y)) { val o = b[x0][y]; if (o != null && o.w != p.w) l.add(x0 to y) }
            }
            'n' -> for (a in -3..3) for (c in -3..3) {
                val x = x0 + a; val y = y0 + c
                if (inb(x, y) && b[x][y] == null) l.add(x to y)
            }
            'b', 'r' -> {
                val dirs = if (p.t == 'b') DD else D4
                for (d in dirs) for (i in 1..3) {
                    val x = x0 + d[0] * i; val y = y0 + d[1] * i
                    if (!inb(x, y)) break
                    val o = b[x][y]
                    if (o != null) {
                        if (o.w != p.w && (p.t == 'r' || (o.t != 'k' && o.t != 'q'))) l.add(x to y)
                        break
                    }
                }
            }
            'q' -> for (x in 0..7) for (y in 0..7) {
                val o = b[x][y]
                if (o != null && o.w == p.w && !(x == x0 && y == y0)) l.add(x to y)
            }
            'k' -> for (x in 0..7) for (y in 0..7) {
                val o = b[x][y]
                if (o != null && o.w != p.w && o.t != 'k' && max(abs(x - x0), abs(y - y0)) <= 2) l.add(x to y)
            }
        }
        return l
    }

    private fun endTurn() {
        white = !white
        for (x in 0..7) for (y in 0..7) {
            val p = b[x][y] ?: continue
            if (p.w == white) b[x][y] = p.copy(cd = max(0, p.cd - 1), fr = max(0, p.fr - 1))
        }
    }

    fun applyMove(fx: Int, fy: Int, tx: Int, ty: Int) {
        val p = b[fx][fy] ?: return
        val t = b[tx][ty]
        if (t != null && t.t == 'k') winner = if (p.w) 1 else 2
        b[fx][fy] = null
        b[tx][ty] = if (p.t == 'p' && (ty == 7 || ty == 0)) p.copy(t = 'q') else p
        endTurn()
    }

    fun applyPower(fx: Int, fy: Int, tx: Int, ty: Int) {
        val p = b[fx][fy] ?: return
        val t = b[tx][ty]
        val used = p.copy(cd = 5)
        when (p.t) {
            'p', 'r' -> {
                if (t != null && t.t == 'k') winner = if (p.w) 1 else 2
                b[tx][ty] = null; b[fx][fy] = used
            }
            'n' -> { b[fx][fy] = null; b[tx][ty] = used }
            'b' -> { if (t != null) b[tx][ty] = t.copy(w = p.w); b[fx][fy] = used }
            'q' -> { b[tx][ty] = used; b[fx][fy] = t }
            'k' -> { if (t != null) b[tx][ty] = t.copy(fr = 3); b[fx][fy] = used }
        }
        endTurn()
    }

    fun apply(a: Act) = if (a.power) applyPower(a.fx, a.fy, a.tx, a.ty) else applyMove(a.fx, a.fy, a.tx, a.ty)

    fun actions(side: Boolean): List<Act> {
        val l = mutableListOf<Act>()
        for (x in 0..7) for (y in 0..7) {
            val p = b[x][y] ?: continue
            if (p.w != side) continue
            for (m in moves(x, y)) l.add(Act(false, x, y, m.first, m.second))
            for (m in targets(x, y)) l.add(Act(true, x, y, m.first, m.second))
        }
        return l
    }

    fun eval(side: Boolean): Double {
        if (winner != 0) return if ((winner == 1) == side) 10000.0 else -10000.0
        var s = 0.0
        for (x in 0..7) for (y in 0..7) {
            val p = b[x][y] ?: continue
            var v = value(p.t)
            if (p.t == 'p') v += 0.05 * (if (p.w) y else 7 - y)
            if (p.fr > 0) v -= 0.4
            if (p.cd == 0) v += 0.15
            s += if (p.w == side) v else -v
        }
        return s
    }
}

object Ai {
    fun best(s: State, hard: Boolean): Act? {
        val side = s.white
        var best: Act? = null
        var bs = -1e9
        for (a in s.actions(side)) {
            val n = s.copy(); n.apply(a)
            var sc = n.eval(side)
            if (hard && n.winner == 0) {
                var worst = 1e9
                for (o in n.actions(!side)) {
                    val m = n.copy(); m.apply(o)
                    worst = minOf(worst, m.eval(side))
                }
                if (worst < 1e9) sc = worst
            }
            sc += Math.random() * 0.3
            if (sc > bs) { bs = sc; best = a }
        }
        return best
    }
}
