package com.chesspowers

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

enum class Mode { AI, LOCAL, HOST, JOIN }

val GOLD = Color(0xFFFFD36B)
val THEME_NAMES = listOf("خشب", "رخام", "نيون")
val THEME_LIGHT = listOf(Color(0xFFEBD9B4), Color(0xFFE8EAF0), Color(0xFF2E45B0))
val THEME_DARK = listOf(Color(0xFF8B5A2B), Color(0xFF5B6478), Color(0xFF6A1FA8))
val THEME_FRAME = listOf(Color(0xFF3B2414), Color(0xFF2A3042), Color(0xFF14143C))
val THEME_BG = listOf(
    listOf(Color(0xFF2B1B12), Color(0xFF0E0906)),
    listOf(Color(0xFF1B2030), Color(0xFF080A12)),
    listOf(Color(0xFF0B0B2A), Color(0xFF020208))
)

fun glyph(t: Char) = when (t) {
    'k' -> "\u265A"; 'q' -> "\u265B"; 'r' -> "\u265C"; 'b' -> "\u265D"; 'n' -> "\u265E"; else -> "\u265F\uFE0E"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    MaterialTheme(colorScheme = darkColorScheme()) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            var screen by remember { mutableStateOf(0) }
            var mode by remember { mutableStateOf(Mode.AI) }
            var theme by remember { mutableStateOf(0) }
            var hard by remember { mutableStateOf(true) }
            var sound by remember { mutableStateOf(true) }
            var net by remember { mutableStateOf<Net?>(null) }
            var wait by remember { mutableStateOf("") }
            var askIp by remember { mutableStateOf(false) }
            var ip by remember { mutableStateOf("192.168.43.1") }
            Sfx.on = sound

            fun startNet(m: Mode) {
                net?.close()
                val n = Net { msg ->
                    if (msg == "C") screen = 1
                    else if (msg == "X") wait = "تعذّر الاتصال، تأكد من العنوان ومن أن الجهازين على نفس الشبكة"
                }
                net = n; mode = m
                if (m == Mode.HOST) { wait = "بانتظار اللاعب الآخر…\nعنوانك: ${Net.localIp()}"; n.host() }
                else { wait = "جاري الاتصال…"; n.join(ip) }
            }

            if (screen == 1) {
                Game(mode, net, theme, hard) { net?.close(); net = null; screen = 0; wait = "" }
            } else {
                Menu(theme, hard, sound, wait,
                    onAi = { net?.close(); net = null; mode = Mode.AI; screen = 1 },
                    onLocal = { net?.close(); net = null; mode = Mode.LOCAL; screen = 1 },
                    onHost = { startNet(Mode.HOST) },
                    onJoin = { askIp = true },
                    onTheme = { theme = (theme + 1) % 3 },
                    onHard = { hard = !hard },
                    onSound = { sound = !sound })
                if (askIp) AlertDialog(
                    onDismissRequest = { askIp = false },
                    title = { Text("عنوان المضيف") },
                    text = { OutlinedTextField(value = ip, onValueChange = { ip = it }, singleLine = true) },
                    confirmButton = { TextButton(onClick = { askIp = false; startNet(Mode.JOIN) }) { Text("اتصال") } },
                    dismissButton = { TextButton(onClick = { askIp = false }) { Text("إلغاء") } })
            }
        }
    }
}

@Composable
fun MBtn(t: String, onClick: () -> Unit) {
    Button(onClick, Modifier.fillMaxWidth().padding(vertical = 5.dp).height(54.dp), shape = RoundedCornerShape(16.dp)) {
        Text(t, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Menu(theme: Int, hard: Boolean, sound: Boolean, wait: String,
         onAi: () -> Unit, onLocal: () -> Unit, onHost: () -> Unit, onJoin: () -> Unit,
         onTheme: () -> Unit, onHard: () -> Unit, onSound: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF14183A), Color(0xFF05060F)))).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text("\u265E\uFE0E", fontSize = 76.sp, color = GOLD)
        Text("شطرنج القدرات", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(26.dp))
        MBtn("لاعب واحد ضد الحاسوب", onAi)
        MBtn("لاعبان على جهاز واحد", onLocal)
        MBtn("استضافة لعبة (نقطة اتصال)", onHost)
        MBtn("الانضمام إلى لعبة", onJoin)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onTheme, Modifier.weight(1f)) { Text("اللوحة: " + THEME_NAMES[theme], fontSize = 13.sp) }
            OutlinedButton(onHard, Modifier.weight(1f)) { Text("الصعوبة: " + (if (hard) "صعب" else "سهل"), fontSize = 13.sp) }
            OutlinedButton(onSound, Modifier.weight(1f)) { Text("الصوت: " + (if (sound) "يعمل" else "كتم"), fontSize = 13.sp) }
        }
        if (wait.isNotEmpty()) Text(wait, color = GOLD, fontSize = 16.sp, modifier = Modifier.padding(top = 18.dp))
    }
}

class P3(val x: Float, val y: Float, val k: Float, val rz: Float)

class Proj(val w: Float, val h: Float, val zoom: Float, val pan: Offset, val flip: Boolean) {
    private val th = Math.toRadians(52.0)
    private val cs = cos(th).toFloat()
    private val sn = sin(th).toFloat()
    private val d = 14f
    val s = min(w, h * 1.1f) / 9.2f * zoom
    fun p(x: Float, y: Float, hg: Float = 0f): P3 {
        var u = x - 3.5f; var v = y - 3.5f
        if (flip) { u = -u; v = -v }
        val ry = hg * cs + v * sn
        val rz = v * cs - hg * sn
        val k = d / (d + rz)
        return P3(w / 2 + pan.x + u * k * s, h * 0.45f + pan.y - ry * k * s, k, rz)
    }
}

fun inQuad(p: List<P3>, o: Offset): Boolean {
    var pos = 0; var neg = 0
    for (i in 0..3) {
        val a = p[i]; val b = p[(i + 1) % 4]
        val c = (b.x - a.x) * (o.y - a.y) - (b.y - a.y) * (o.x - a.x)
        if (c > 0) pos++ else neg++
    }
    return pos == 0 || neg == 0
}

@Composable
fun Game(mode: Mode, net: Net?, theme: Int, hard: Boolean, onExit: () -> Unit) {
    var st by remember { mutableStateOf(State.start()) }
    var sel by remember { mutableStateOf<Sq?>(null) }
    var power by remember { mutableStateOf(false) }
    var last by remember { mutableStateOf<Act?>(null) }
    var zoom by remember { mutableStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var sz by remember { mutableStateOf(IntSize.Zero) }
    var disc by remember { mutableStateOf(false) }
    val flip = mode == Mode.JOIN

    fun mine(): Boolean = when (mode) {
        Mode.LOCAL -> true; Mode.AI -> st.white; Mode.HOST -> st.white; Mode.JOIN -> !st.white
    }

    val hl: List<Sq> = remember(st, sel, power) {
        val s = sel
        if (s == null) emptyList() else if (power) st.targets(s.first, s.second) else st.moves(s.first, s.second)
    }

    fun doAct(a: Act, send: Boolean) {
        val s = st.copy()
        val victim = s.b[a.tx][a.ty]
        s.apply(a)
        st = s; last = a; sel = null; power = false
        if (s.winner != 0) Sfx.win() else if (a.power) Sfx.power() else if (victim != null) Sfx.cap() else Sfx.move()
        if (send) net?.send("A ${if (a.power) 1 else 0} ${a.fx} ${a.fy} ${a.tx} ${a.ty}")
    }

    BackHandler { onExit() }

    DisposableEffect(net) {
        net?.onMsg = { m ->
            if (m == "D") disc = true
            else if (m.startsWith("A ")) {
                val v = m.split(" ")
                doAct(Act(v[1] == "1", v[2].toInt(), v[3].toInt(), v[4].toInt(), v[5].toInt()), false)
            }
        }
        onDispose { }
    }

    LaunchedEffect(st.white, st.winner) {
        if (mode == Mode.AI && !st.white && st.winner == 0) {
            delay(600)
            val s0 = st.copy()
            val a = withContext(Dispatchers.Default) { Ai.best(s0, hard) }
            if (a != null) doAct(a, false)
        }
    }

    fun pieces(): List<Triple<Int, Int, Pc>> {
        val l = mutableListOf<Triple<Int, Int, Pc>>()
        for (x in 0..7) for (y in 0..7) { val p = st.b[x][y]; if (p != null) l.add(Triple(x, y, p)) }
        return l
    }

    fun clickSq(x: Int, y: Int) {
        if (sel != null && hl.contains(x to y)) {
            val s = sel!!
            doAct(Act(power, s.first, s.second, x, y), true)
            return
        }
        val p = st.b[x][y]
        if (p != null && p.w == st.white) { sel = x to y; power = false } else sel = null
    }

    fun onTapImpl(o: Offset) {
        if (st.winner != 0 || !mine()) return
        val pr = Proj(sz.width.toFloat(), sz.height.toFloat(), zoom, pan, flip)
        var hit: Sq? = null
        for ((x, y, _) in pieces().sortedBy { pr.p(it.first.toFloat(), it.second.toFloat()).rz }) {
            val c = pr.p(x.toFloat(), y.toFloat(), 0.5f)
            val r = pr.s * c.k * 0.55f
            val dx = o.x - c.x; val dy = o.y - c.y
            if (dx * dx + dy * dy < r * r) { hit = x to y; break }
        }
        if (hit == null) {
            loop@ for (x in 0..7) for (y in 0..7) {
                val q = listOf(pr.p(x - .5f, y - .5f), pr.p(x + .5f, y - .5f), pr.p(x + .5f, y + .5f), pr.p(x - .5f, y + .5f))
                if (inQuad(q, o)) { hit = x to y; break@loop }
            }
        }
        if (hit != null) clickSq(hit.first, hit.second)
    }
    val tapRef = rememberUpdatedState<(Offset) -> Unit> { o -> onTapImpl(o) }

    val fill = remember { android.graphics.Paint().apply { isAntiAlias = true; textAlign = android.graphics.Paint.Align.CENTER } }
    val stroke = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true; textAlign = android.graphics.Paint.Align.CENTER
            style = android.graphics.Paint.Style.STROKE
        }
    }

    Box(Modifier.fillMaxSize()) {
        Canvas(
            Modifier.fillMaxSize().onSizeChanged { sz = it }
                .pointerInput(Unit) {
                    detectTransformGestures { _, pc, z, _ ->
                        zoom = (zoom * z).coerceIn(0.6f, 2.6f); pan += pc
                    }
                }
                .pointerInput(Unit) { detectTapGestures { tapRef.value(it) } }
        ) {
            val pr = Proj(size.width, size.height, zoom, pan, flip)
            drawRect(Brush.verticalGradient(THEME_BG[theme]))
            fun quad(x0: Float, y0: Float, x1: Float, y1: Float, dy: Float = 0f): Path {
                val a = pr.p(x0, y0); val b2 = pr.p(x1, y0); val c = pr.p(x1, y1); val d = pr.p(x0, y1)
                return Path().apply {
                    moveTo(a.x, a.y + dy); lineTo(b2.x, b2.y + dy); lineTo(c.x, c.y + dy); lineTo(d.x, d.y + dy); close()
                }
            }
            drawPath(quad(-.8f, -.8f, 7.8f, 7.8f, pr.s * .4f), Color.Black.copy(alpha = .55f))
            drawPath(quad(-.8f, -.8f, 7.8f, 7.8f), THEME_FRAME[theme])
            for (x in 0..7) for (y in 0..7) {
                val c = if ((x + y) % 2 == 0) THEME_DARK[theme] else THEME_LIGHT[theme]
                val q = quad(x - .5f, y - .5f, x + .5f, y + .5f)
                drawPath(q, c)
                val l = last
                if (l != null && ((l.fx == x && l.fy == y) || (l.tx == x && l.ty == y))) drawPath(q, Color(0xFF4D8DFF).copy(alpha = .35f))
                if (sel == (x to y)) drawPath(q, GOLD.copy(alpha = .6f))
                if (hl.contains(x to y)) drawPath(q, (if (power) Color(0xFFFF8000) else Color(0xFF33FF66)).copy(alpha = .55f))
            }
            val list = pieces().sortedByDescending { pr.p(it.first.toFloat(), it.second.toFloat()).rz }
            drawIntoCanvas { cv ->
                val nc = cv.nativeCanvas
                for ((x, y, p) in list) {
                    val lift = if (sel == (x to y)) .35f else 0f
                    val bse = pr.p(x.toFloat(), y.toFloat())
                    val ctr = pr.p(x.toFloat(), y.toFloat(), .5f + lift)
                    drawOval(Color.Black.copy(alpha = .38f), Offset(bse.x - pr.s * bse.k * .36f, bse.y - pr.s * bse.k * .12f), Size(pr.s * bse.k * .72f, pr.s * bse.k * .24f))
                    val ts = pr.s * ctr.k * 1.4f
                    fill.textSize = ts; stroke.textSize = ts; stroke.strokeWidth = ts * .06f
                    var fc = if (p.w) Color(0xFFFFF4D6) else Color(0xFF1B1B26)
                    if (p.fr > 0) fc = Color(0xFF6FA8FF)
                    fill.color = fc.toArgb()
                    stroke.color = (if (p.w) Color(0xFF2A1A0A) else Color(0xFFE8E0C8)).toArgb()
                    val g = glyph(p.t)
                    nc.drawText(g, ctr.x, ctr.y + ts * .33f, stroke)
                    nc.drawText(g, ctr.x, ctr.y + ts * .33f, fill)
                    if (p.cd == 0 && p.fr == 0) drawCircle(GOLD, pr.s * ctr.k * .07f, Offset(ctr.x + ts * .32f, ctr.y - ts * .42f))
                }
            }
        }

        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text("القائمة", color = Color.White) }
            val turn = if (st.winner != 0) "انتهت اللعبة" else (if (st.white) "دور الأبيض" else "دور الأسود") +
                (if (mode == Mode.HOST || mode == Mode.JOIN) (if (mine()) " (دورك)" else " (الخصم)") else "")
            Text(turn, Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            FilledTonalButton(onClick = { zoom = (zoom * 1.2f).coerceAtMost(2.6f) }, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(40.dp)) { Text("+", fontSize = 20.sp) }
            Spacer(Modifier.width(6.dp))
            FilledTonalButton(onClick = { zoom = (zoom / 1.2f).coerceAtLeast(0.6f) }, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(40.dp)) { Text("−", fontSize = 20.sp) }
        }

        val sp = sel?.let { st.b[it.first][it.second] }
        AnimatedVisibility(visible = sp != null, modifier = Modifier.align(Alignment.BottomCenter)) {
            if (sp != null && sel != null) {
                val s = sel!!
                Card(Modifier.fillMaxWidth().padding(12.dp), shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xF0121530))) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(glyph(sp.t), fontSize = 36.sp, color = GOLD)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(NAMES[sp.t] + (if (sp.w) " أبيض" else " أسود"), fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
                                Text("القدرة: " + POWER_NAME[sp.t], color = GOLD, fontSize = 15.sp)
                            }
                        }
                        Text(POWER_DESC[sp.t] ?: "", color = Color(0xFFCCD0E8), fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                        val ready = sp.cd == 0 && sp.fr == 0
                        val status = if (sp.fr > 0) "مجمّدة لمدة ${sp.fr} أدوار" else if (sp.cd > 0) "تجهز بعد ${sp.cd} أدوار" else if (power) "اختر الهدف على اللوحة" else "القدرة جاهزة"
                        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(status, Modifier.weight(1f), color = if (ready) Color(0xFF6BFF9A) else Color(0xFFFFB36B), fontSize = 14.sp)
                            Button(onClick = { power = !power },
                                enabled = ready && (power || st.targets(s.first, s.second).isNotEmpty())) {
                                Text(if (power) "إلغاء" else "استخدم القدرة")
                            }
                        }
                    }
                }
            }
        }

        if (st.winner != 0) AlertDialog(
            onDismissRequest = { },
            title = { Text(if (st.winner == 1) "فاز الأبيض 🏆" else "فاز الأسود 🏆") },
            confirmButton = {
                if (mode == Mode.AI || mode == Mode.LOCAL)
                    TextButton(onClick = { st = State.start(); sel = null; power = false; last = null }) { Text("لعبة جديدة") }
                else TextButton(onClick = onExit) { Text("القائمة") }
            },
            dismissButton = { TextButton(onClick = onExit) { Text("القائمة") } })

        if (disc) AlertDialog(
            onDismissRequest = { },
            title = { Text("انقطع الاتصال") },
            confirmButton = { TextButton(onClick = onExit) { Text("القائمة") } })
    }
}
